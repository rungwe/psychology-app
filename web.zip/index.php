<?php
    require "components.php";
    echo main_page();
    
    
    
?>


